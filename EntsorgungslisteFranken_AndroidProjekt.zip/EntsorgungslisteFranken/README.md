# Entsorgungsliste Franken – Android-Projekt

Native Android-App für eine komplette Besichtigung per Sprache.

## Ablauf
1. Kunde und Objektadresse eintragen.
2. **Besichtigung starten** drücken.
3. Die komplette Besichtigung frei durchsprechen. Die App startet die Android-Spracherkennung nach kurzen Erkennungsabschnitten automatisch erneut.
4. **Beenden** drücken.
5. **Word-Datei erstellen** wählen und Speicherort auswählen.

Die Word-Datei wird als Word-kompatible `.doc`-Datei erzeugt und enthält Kundendaten, Datum, das erkannte Entsorgungsgut sowie Bemerkungen und Firmendaten.

## Technischer Hinweis
Die App verwendet Android `SpeechRecognizer` und nicht die Browser-API `webkitSpeechRecognition`.

Zum Bauen wird Android Studio mit Android SDK benötigt. Projekt öffnen, Gradle synchronisieren und `app` als Build-Variante `debug` bauen.
