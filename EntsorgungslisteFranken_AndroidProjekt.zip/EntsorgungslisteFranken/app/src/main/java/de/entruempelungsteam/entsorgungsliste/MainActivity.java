package de.entruempelungsteam.entsorgungsliste;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.os.Bundle;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.view.View;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.regex.*;

public class MainActivity extends Activity {
    private static final int REQ_AUDIO=10, REQ_FILE=20;
    private EditText customer,address,notes,transcript;
    private TextView status;
    private Button start,stop,word;
    private SpeechRecognizer recognizer;
    private boolean recording=false;
    private StringBuilder fullText=new StringBuilder();

    @Override public void onCreate(Bundle b){ super.onCreate(b); buildUi(); }

    private TextView label(String s){ TextView t=new TextView(this); t.setText(s); t.setTextSize(16); t.setTypeface(null,Typeface.BOLD); t.setPadding(0,18,0,6); return t; }
    private EditText field(String hint){ EditText e=new EditText(this); e.setHint(hint); e.setTextSize(16); e.setSingleLine(false); return e; }

    private void buildUi(){
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(28,20,28,24);
        ScrollView scroll=new ScrollView(this); LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL);
        TextView title=label("ENTRÜMPELUNGSTEAM FRANKEN"); title.setTextSize(22); title.setTextColor(0xffb00020); box.addView(title);
        TextView sub=new TextView(this); sub.setText("Entsorgungsliste – Besichtigung"); sub.setTextSize(18); box.addView(sub);
        box.addView(label("Kunde")); customer=field("Name des Kunden"); box.addView(customer);
        box.addView(label("Objektadresse")); address=field("Straße, Ort"); box.addView(address);
        box.addView(label("Besichtigung"));
        status=new TextView(this); status.setText("Bereit"); status.setTextSize(16); box.addView(status);
        LinearLayout buttons=new LinearLayout(this); buttons.setOrientation(LinearLayout.HORIZONTAL);
        start=new Button(this); start.setText("🎙 Besichtigung starten"); buttons.addView(start,new LinearLayout.LayoutParams(0,-2,1));
        stop=new Button(this); stop.setText("■ Beenden"); stop.setEnabled(false); buttons.addView(stop,new LinearLayout.LayoutParams(0,-2,1)); box.addView(buttons);
        box.addView(label("Gesprochene Besichtigung")); transcript=field("Hier erscheint automatisch das Gesprochene …"); transcript.setMinLines(8); transcript.setGravity(48); box.addView(transcript);
        box.addView(label("Bemerkungen")); notes=field("Zusätzliche Bemerkungen"); notes.setMinLines(3); box.addView(notes);
        word=new Button(this); word.setText("Word-Datei erstellen"); word.setEnabled(false); box.addView(word);
        TextView hint=new TextView(this); hint.setText("Tipp: Sprich frei durch, z. B. 'Wohnzimmer: Wohnwand, Sofa, zwei Sessel. Keller: Waschmaschine, Regale …'. Du musst nicht nach jedem Gegenstand stoppen."); hint.setPadding(0,18,0,0); box.addView(hint);
        scroll.addView(box); root.addView(scroll); setContentView(root);
        start.setOnClickListener(v->begin()); stop.setOnClickListener(v->finishRecording()); word.setOnClickListener(v->createWord());
    }

    private void begin(){
        if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){ requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},REQ_AUDIO); return; }
        fullText.setLength(0); transcript.setText(""); recording=true; start.setEnabled(false); stop.setEnabled(true); word.setEnabled(false); status.setText("🔴 Aufnahme läuft – bitte komplette Besichtigung sprechen …");
        startRecognizer();
    }
    private void startRecognizer(){
        if(!SpeechRecognizer.isRecognitionAvailable(this)){ status.setText("Spracherkennung ist auf diesem Gerät nicht verfügbar."); recording=false; start.setEnabled(true); stop.setEnabled(false); return; }
        if(recognizer!=null) recognizer.destroy(); recognizer=SpeechRecognizer.createSpeechRecognizer(this);
        recognizer.setRecognitionListener(new RecognitionListener(){
            public void onReadyForSpeech(Bundle p){}
            public void onBeginningOfSpeech(){}
            public void onRmsChanged(float r){}
            public void onBufferReceived(byte[] b){}
            public void onEndOfSpeech(){ if(recording) restartSoon(); }
            public void onError(int e){ if(recording) restartSoon(); }
            public void onResults(Bundle b){
                ArrayList<String> r=b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if(r!=null && !r.isEmpty()){ String s=r.get(0).trim(); if(!s.isEmpty()){ if(fullText.length()>0) fullText.append(" "); fullText.append(s); transcript.setText(clean(fullText.toString())); transcript.setSelection(transcript.length()); word.setEnabled(true); } }
                if(recording) restartSoon();
            }
            public void onPartialResults(Bundle b){ ArrayList<String> r=b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION); if(r!=null&&!r.isEmpty()){ String temp=fullText.toString(); String p=r.get(0); transcript.setText(clean(temp+(temp.isEmpty()?"":" ")+p)); } }
            public void onEvent(int t,Bundle p){}
        });
        Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH); i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM); i.putExtra(RecognizerIntent.EXTRA_LANGUAGE,"de-DE"); i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS,true); i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS,3); recognizer.startListening(i);
    }
    private void restartSoon(){ if(!recording)return; new android.os.Handler().postDelayed(()->{if(recording)startRecognizer();},250); }
    private void finishRecording(){ recording=false; if(recognizer!=null){recognizer.stopListening();recognizer.destroy();recognizer=null;} start.setEnabled(true); stop.setEnabled(false); status.setText("Aufnahme beendet. Die Liste kann jetzt als Word-Datei gespeichert werden."); word.setEnabled(fullText.length()>0); transcript.setText(clean(fullText.toString())); }
    private String clean(String s){ return s.replaceAll("\\s+"," ").replaceAll("\\s+([,.;:])","$1").trim(); }

    private void createWord(){
        String html=buildHtml(); Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT); i.setType("application/msword"); i.putExtra(Intent.EXTRA_TITLE,"Entsorgungsliste_"+(customer.getText().toString().trim().isEmpty()?"Besichtigung":safe(customer.getText().toString().trim()))+".doc"); startActivityForResult(i,REQ_FILE); getSharedPreferences("draft",0).edit().putString("html",html).apply();
    }
    private String buildHtml(){
        String raw=clean(fullText.toString()); String structured=structure(raw);
        String d=new SimpleDateFormat("dd.MM.yyyy",Locale.GERMANY).format(new Date());
        return "<html><head><meta charset='UTF-8'><style>body{font-family:Arial}h1{color:#b00020}h2{margin-top:18px}.meta{margin-bottom:20px}li{margin:4px}</style></head><body>"+
        "<h1>Entrümpelungsteam Franken</h1><h2>Entsorgungsliste – Besichtigung</h2>"+
        "<div class='meta'><b>Kunde:</b> "+esc(customer.getText().toString())+"<br><b>Objekt:</b> "+esc(address.getText().toString())+"<br><b>Datum:</b> "+d+"</div>"+
        "<h2>Entsorgungsgut</h2>"+structured+"<h2>Bemerkungen</h2><p>"+esc(notes.getText().toString()).replace("\n","<br>")+"</p>"+
        "<hr><p>Entrümpelungsteam Franken<br>01578/704 84 43<br>www.entrümpelungsteam.de</p></body></html>";
    }
    private String structure(String raw){
        if(raw.isEmpty()) return "<p>Keine Spracheingabe vorhanden.</p>";
        String[] rooms={"Keller","Dachboden","Dachspitze","Garage","Garten","Küche","Wohnzimmer","Schlafzimmer","Kinderzimmer","Flur","Bad","Badezimmer","Esszimmer","Büro","Arbeitszimmer","Abstellraum","Hobbyraum","Speicher"};
        String x=raw; for(String r:rooms) x=x.replaceAll("(?i)\\b"+Pattern.quote(r)+"\\s*[:,-]", "|||"+r+"||| ");
        String[] parts=x.split("\\|\\|\\|"); StringBuilder out=new StringBuilder();
        if(parts.length==1) return "<ul><li>"+esc(raw)+"</li></ul>";
        for(int i=0;i<parts.length;i++){String p=parts[i].trim(); if(p.isEmpty())continue; if(i%2==1){out.append("<h3>").append(esc(p)).append("</h3>");}else{String[] items=p.split("[,;.]"); out.append("<ul>"); for(String it:items) if(!it.trim().isEmpty()) out.append("<li>").append(esc(it.trim())).append("</li>"); out.append("</ul>");}}
        return out.toString();
    }
    private String esc(String s){return s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;");}
    private String safe(String s){return s.replaceAll("[^a-zA-Z0-9ÄÖÜäöüß _-]","").replace(' ','_');}
    @Override protected void onActivityResult(int req,int result,Intent data){super.onActivityResult(req,result,data); if(req==REQ_FILE&&result==RESULT_OK&&data!=null){String html=getSharedPreferences("draft",0).getString("html",""); try{java.io.OutputStream o=getContentResolver().openOutputStream(data.getData()); o.write(html.getBytes("UTF-8")); o.close(); Toast.makeText(this,"Word-Datei wurde erstellt.",Toast.LENGTH_LONG).show();}catch(Exception e){Toast.makeText(this,"Fehler beim Speichern: "+e.getMessage(),Toast.LENGTH_LONG).show();}}}
    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){super.onRequestPermissionsResult(r,p,g); if(r==REQ_AUDIO&&g.length>0&&g[0]==PackageManager.PERMISSION_GRANTED)begin(); else status.setText("Mikrofon-Berechtigung wurde nicht erteilt.");}
    @Override protected void onDestroy(){recording=false;if(recognizer!=null)recognizer.destroy();super.onDestroy();}
}
